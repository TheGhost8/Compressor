#pragma once

#define MAX_FREQUENCY 0x00004FFF
#define AGGRESIVENESS 10