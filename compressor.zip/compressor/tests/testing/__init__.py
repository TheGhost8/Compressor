
TIME_LIMIT = 'TL'
RUNTIME_ERROR = 'RE'
OK = 'OK'
WRONG_ANSWER = 'WA'

from .compressor import Compressor
from .command import ExecutableNotFoundError
