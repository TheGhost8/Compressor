#pragma once

void compress_ppm(char *ifile, char *ofile);
void decompress_ppm(char *ifile, char *ofile);
