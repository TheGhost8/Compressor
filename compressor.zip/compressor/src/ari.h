#pragma once

void compress_ari(char *ifile, char *ofile);
void decompress_ari(char *ifile, char *ofile);
