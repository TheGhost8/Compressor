#pragma once

void compress_bwt(char *ifile, char *ofile);
void decompress_bwt(char *ifile, char *ofile);
